export class General {
    question:string;
    answer:{option:string,correct:boolean}[];
}
