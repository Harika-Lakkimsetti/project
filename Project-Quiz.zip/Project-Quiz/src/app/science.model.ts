export class Science {
    question:string;
    answer:{option:string,correct:boolean}[];
}
