import { Science } from './science.model';

describe('Science', () => {
  it('should create an instance', () => {
    expect(new Science()).toBeTruthy();
  });
});
